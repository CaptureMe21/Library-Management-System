package com.example.androidtryy.JavaClass;

public class Borrowed {
    private String booktitle;
    private String isbn;
    private String quantity;
    private String transactionId;
    private String borrowdate;
    private String returndate;
    private String bname;
    private String idnum;


    // Default constructor required for calls to DataSnapshot.getValue(Borrowed.class)
    public Borrowed() {
    }

    public Borrowed(String booktitle, String isbn, String quantity, String transactionId, String borrowdate, String returndate, String name, String idnum) {
        this.booktitle = booktitle;
        this.isbn = isbn;
        this.quantity = quantity;
        this.transactionId = transactionId;
        this.borrowdate = borrowdate;
        this.returndate = returndate;
        this.bname = bname;
        this.idnum = idnum;
    }

    public String getBooktitle() {
        return booktitle;
    }

    public void setBooktitle(String booktitle) {
        this.booktitle = booktitle;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getBorrowdate() {
        return borrowdate;
    }

    public void setBorrowdate(String borrowdate) {
        this.borrowdate = borrowdate;
    }

    public String getReturndate() {
        return returndate;
    }

    public void setReturndate(String returndate) {
        this.returndate = returndate;
    }

    public String getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname = bname;
    }

    public String getIdnum() {
        return idnum;
    }

    public void setIdnum(String idnum) {
        this.idnum = idnum;
    }
}
