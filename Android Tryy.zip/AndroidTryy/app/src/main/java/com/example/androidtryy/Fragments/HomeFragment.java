package com.example.androidtryy.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.androidtryy.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private TextView welcomeMessage;
    private TextView reminderMessage;
    private TextView announcementMessage, announcementTitle, announcementAuthor, announcementDate; // Added this line

    private DatabaseReference borrowedBooksRef;
    private ValueEventListener borrowedBooksListener;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        welcomeMessage = view.findViewById(R.id.welcome_message);
        reminderMessage = view.findViewById(R.id.reminder_message);
        announcementTitle = view.findViewById(R.id.tv_atitle);
        announcementDate = view.findViewById(R.id.date_holder);
        announcementMessage = view.findViewById(R.id.tv_abody);
        announcementAuthor = view.findViewById(R.id.name_holder);
        displayWelcomeMessage();
        setupBorrowedBooksListener();
        displayLatestAnnouncement();
        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (borrowedBooksRef != null && borrowedBooksListener != null) {
            borrowedBooksRef.removeEventListener(borrowedBooksListener);
        }
    }

    private void displayWelcomeMessage() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String uid = user.getUid();
            DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference().child("Users").child(uid);
            usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String userName = snapshot.child("namef").getValue(String.class);
                        welcomeMessage.setText("Welcome, " + userName + "!");
                    } else {
                        welcomeMessage.setText("Welcome!");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    welcomeMessage.setText("Welcome!");
                }
            });
        } else {
            welcomeMessage.setText("Welcome!");
        }
    }

    private void setupBorrowedBooksListener() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String uid = user.getUid();
            borrowedBooksRef = FirebaseDatabase.getInstance().getReference().child("BorrowedBooks");
            borrowedBooksListener = new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    boolean hasBorrowedBook = false;
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        String transactionUid = dataSnapshot.child("uid").getValue(String.class);
                        if (uid.equals(transactionUid)) {
                            hasBorrowedBook = true;
                            break;
                        }
                    }
                    if (hasBorrowedBook) {
                        reminderMessage.setText("You have a borrowed book. Please return the book on or before the scheduled return date of the book. Thank you.");
                    } else {
                        reminderMessage.setText("You have no borrowed book. Books train your mind to imagination to think big. – Taylor Swift");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle error
                }
            };
            borrowedBooksRef.addValueEventListener(borrowedBooksListener);
        }
    }

    private void displayLatestAnnouncement() {
        DatabaseReference announcementRef = FirebaseDatabase.getInstance().getReference().child("Announcements");
        announcementRef.orderByKey().limitToLast(1).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        String latestAnnouncement = dataSnapshot.child("message").getValue(String.class);
                        String latestAnnouncementTitle = dataSnapshot.child("title").getValue(String.class);
                        String latestAnnouncementAuthorId = dataSnapshot.child("userId").getValue(String.class);
                        String latestAnnouncementDate = dataSnapshot.child("date").getValue(String.class);

                        // Fetch the latest announcement author's name from the Users node
                        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference().child("Users").child(latestAnnouncementAuthorId);
                        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot userSnapshot) {
                                if (userSnapshot.exists()) {
                                    String latestAnnouncementAuthorFirstName = userSnapshot.child("namef").getValue(String.class);
                                    String latestAnnouncementAuthorLastName = userSnapshot.child("namel").getValue(String.class);
                                    String latestAnnouncementAuthor = latestAnnouncementAuthorFirstName + " " + latestAnnouncementAuthorLastName;

                                    // Set the announcement title and message with author's name
                                    announcementTitle.setText(latestAnnouncementTitle != null ? latestAnnouncementTitle : "No title available");
                                    announcementMessage.setText(latestAnnouncement != null ? latestAnnouncement : "No announcement available.");
                                    announcementAuthor.setText(latestAnnouncementAuthor != null ? latestAnnouncementAuthor : "No author available.");
                                    announcementDate.setText(latestAnnouncementDate != null ? latestAnnouncementDate : "0000/00/00");
                                } else {
                                    // Handle if user data doesn't exist
                                    announcementTitle.setText("No announcements available yet.");
                                    announcementMessage.setText("No announcements available yet.");
                                    announcementAuthor.setText("No Authors available yet.");
                                    announcementDate.setText("0000/00/00");
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                announcementMessage.setText("Failed to load announcement.");
                            }
                        });
                    }
                } else {
                    announcementTitle.setText("No announcement available yet.");
                    announcementMessage.setText("No announcement available yet.");
                    announcementAuthor.setText("No Authors available yet.");
                    announcementDate.setText("0000/00/00");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                announcementMessage.setText("Failed to load announcement.");
            }
        });
    }

}