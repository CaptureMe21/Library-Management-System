package com.example.androidtryy.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.androidtryy.Activity.ReturnActivity;
import com.example.androidtryy.R;
import com.google.android.material.button.MaterialButton;

public class ReturnFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    String booktitle, isbn, quantity, transactionId, borrowdate, returndate, bname, idnum;

    public ReturnFragment() {
        // Required empty public constructor
    }

    public ReturnFragment(String booktitle, String isbn, String quantity, String transactionId, String borrowdate, String returndate, String bname, String idnum) {
        this.booktitle = booktitle;
        this.isbn = isbn;
        this.quantity = quantity;
        this.transactionId = transactionId;
        this.borrowdate = borrowdate;
        this.returndate = returndate;
        this.bname = bname;
        this.idnum = idnum;
    }

    public static ReturnFragment newInstance(String param1, String param2) {
        ReturnFragment fragment = new ReturnFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_return, container, false);

        // Find views by their IDs
        TextView transactionholder = view.findViewById(R.id.transaction_holder);
        TextView booktitleholder = view.findViewById(R.id.title_holders);
        TextView isbnholder = view.findViewById(R.id.isbn_holders);
        TextView quantityholder = view.findViewById(R.id.quantity_holders);
        TextView borrowdateholder = view.findViewById(R.id.borrow_holders);
        TextView returndateholder = view.findViewById(R.id.return_holders);
        MaterialButton returnbtn = view.findViewById(R.id.rb_btn);

        // Set text to TextViews
        transactionholder.setText(transactionId);
        booktitleholder.setText(booktitle);
        isbnholder.setText(isbn);
        quantityholder.setText(quantity);
        borrowdateholder.setText(borrowdate);
        returndateholder.setText(returndate);

        returnbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Only proceed if quantity is greater than 0
                if (!quantity.equals("0")) {
                    Intent intent = new Intent(view.getContext(), ReturnActivity.class);
                    // Add data as extras

                    intent.putExtra("transactionId", transactionId);
                    intent.putExtra("booktitle", booktitle);
                    intent.putExtra("isbn", isbn);
                    intent.putExtra("quantity", quantity);
                    intent.putExtra("bname", bname);
                    intent.putExtra("idnum", idnum);
                    // Start the new activity
                    startActivity(intent);
                }
            }
        });

        return view;
    }
}