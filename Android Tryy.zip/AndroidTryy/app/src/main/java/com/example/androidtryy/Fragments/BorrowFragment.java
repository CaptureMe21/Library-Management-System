package com.example.androidtryy.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.androidtryy.Activity.BorrowActivity;
import com.example.androidtryy.R;
import com.google.android.material.button.MaterialButton;

public class BorrowFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    String booktitle, author, edition, volume, genre, quantity, shelfnumber, pagenumber, isbn;
    MaterialButton bb_btn, rb_button;
    public BorrowFragment() {
    }

    public BorrowFragment(String booktitle, String author, String edition, String volume, String genre, String quantity, String shelfnumber, String pagenumber, String isbn) {
        this.booktitle = booktitle;
        this.author = author;
        this.edition = edition;
        this.volume = volume;
        this.genre = genre;
        this.quantity = quantity;
        this.shelfnumber = shelfnumber;
        this.pagenumber = pagenumber;
        this.isbn = isbn;
    }

    public static BorrowFragment newInstance(String param1, String param2) {
        BorrowFragment fragment = new BorrowFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_book, container, false);

        // Find views by their IDs
        TextView titleholder = view.findViewById(R.id.book_holder);
        TextView authorholder = view.findViewById(R.id.author_holder);
        TextView editionholder = view.findViewById(R.id.edition_holder);
        TextView volumeholder = view.findViewById(R.id.volume_holder);
        TextView quantityholder = view.findViewById(R.id.quantity_holder);
        TextView categoryholder = view.findViewById(R.id.category_holder);
        TextView shelfnumholder = view.findViewById(R.id.shelfnum_holder);
        TextView pagenumholder = view.findViewById(R.id.pagenum_holder);
        TextView isbnholder = view.findViewById(R.id.isbn_holder);
        MaterialButton borrowbtn = view.findViewById(R.id.bb_btn);

        // Set text to TextViews
        titleholder.setText(booktitle);
        authorholder.setText(author);
        editionholder.setText(edition);
        volumeholder.setText(volume);
        quantityholder.setText(quantity);
        categoryholder.setText(genre);
        shelfnumholder.setText(shelfnumber);
        pagenumholder.setText(pagenumber);
        isbnholder.setText(isbn);

        // Disable borrow button if quantity is 0
        if (quantity.equals("0")) {
            borrowbtn.setEnabled(false);
        } else {
            borrowbtn.setEnabled(true);
        }

        borrowbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Only proceed if quantity is greater than 0
                if (!quantity.equals("0")) {
                    Intent intent = new Intent(view.getContext(), BorrowActivity.class);
                    // Add data as extras
                    intent.putExtra("booktitle", booktitle);
                    intent.putExtra("quantity", quantity);
                    intent.putExtra("isbn", isbn);
                    // Start the new activity
                    startActivity(intent);
                }
            }
        });

        return view;
    }

    public void OnBackPressed(){

        AppCompatActivity activity = (AppCompatActivity)getContext();
        activity.getSupportFragmentManager().beginTransaction().replace(R.id.drawer_layout,new BooklistFragment()).addToBackStack(null).commit();
    }
}