package com.example.androidtryy.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidtryy.Model.ReturnHelper;
import com.example.androidtryy.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReturnActivity extends AppCompatActivity {

    private static final String TAG = "ReturnActivity";

    private FirebaseDatabase database;
    private DatabaseReference reference;
    private TextView return_name, return_idnum, returnbook_title, returnbook_isbn, returnbook_quantity, transaction_Id, redirect;
    private MaterialButton rb_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_return);

        // Find views by their IDs
        return_name = findViewById(R.id.return_stname);
        return_idnum = findViewById(R.id.return_stidnum);
        returnbook_isbn = findViewById(R.id.return_isbn);
        returnbook_title = findViewById(R.id.returnbook_btitle);
        returnbook_quantity = findViewById(R.id.return_bquantity);
        transaction_Id = findViewById(R.id.transaction_id);
        redirect = findViewById(R.id.redirect_return);
        rb_btn = findViewById(R.id.rbbtn);

        redirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ReturnActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Retrieve intent data for borrowing book
        Intent intent = getIntent();
        if (intent != null) {
            String booktitle = intent.getStringExtra("booktitle");
            String quantity = intent.getStringExtra("quantity");
            String isbn = intent.getStringExtra("isbn");
            String bname = intent.getStringExtra("bname");
            String idnum = intent.getStringExtra("idnum");
            String transactionId = intent.getStringExtra("transactionId");

            if (booktitle != null) returnbook_title.setText(booktitle);
            if (quantity != null) returnbook_quantity.setText(quantity);
            if (isbn != null) returnbook_isbn.setText(isbn);
            if (bname != null) return_name.setText(bname);
            if (idnum != null) return_idnum.setText(idnum);
            if (transactionId != null) transaction_Id.setText(transactionId);
        }

        rb_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                DatabaseReference returnedBooksRef = FirebaseDatabase.getInstance().getReference("ReturnedBooks");

                // Retrieve other return details
                String bname = return_name.getText().toString();
                String idnum = return_idnum.getText().toString();
                String isbn = returnbook_isbn.getText().toString();
                String booktitle = returnbook_title.getText().toString();
                String quantity = returnbook_quantity.getText().toString();
                String transactionId = transaction_Id.getText().toString();

                // Check for empty fields
                if (bname.isEmpty() || idnum.isEmpty() || isbn.isEmpty() || booktitle.isEmpty() || quantity.isEmpty() || transactionId.isEmpty()) {
                    Toast.makeText(ReturnActivity.this, "Please fill all the fields.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Get the current date
                String returndate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                ReturnHelper returnHelper = new ReturnHelper(bname, idnum, isbn, booktitle, quantity, uid, transactionId, returndate);
                returnedBooksRef.child(transactionId).setValue(returnHelper).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Book return successful
                        DatabaseReference updateBooksRef = FirebaseDatabase.getInstance().getReference("Books");
                        updateBooksRef.child(isbn).child("quantity").setValue(quantity)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        // Book quantity updated successfully
                                        deleteBorrowedBook(transactionId);

                                        Toast.makeText(ReturnActivity.this, "Book Returned Successfully!", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(ReturnActivity.this, MainActivity.class);
                                        startActivity(intent);
                                    }
                                });
                    }
                });
            }
        });
    }

    private void deleteBorrowedBook(String transactionId) {
        DatabaseReference borrowedBooksRef = FirebaseDatabase.getInstance().getReference("BorrowedBooks");
        borrowedBooksRef.child(transactionId).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                // Borrowed book entry deleted successfully
                Toast.makeText(ReturnActivity.this, "Borrowed book entry deleted successfully.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}