package com.example.androidtryy.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidtryy.Fragments.ReturnFragment;
import com.example.androidtryy.JavaClass.Borrowed;
import com.example.androidtryy.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;


public class BorrowAdapter extends FirebaseRecyclerAdapter<Borrowed, BorrowAdapter.MyViewHolder> {

    public BorrowAdapter(@NonNull FirebaseRecyclerOptions<Borrowed> options) {

        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull MyViewHolder holder, int position, @NonNull Borrowed borrowed) {
        holder.tv_titles.setText(borrowed.getBooktitle());
        holder.tv_isbn.setText(borrowed.getIsbn());
        holder.tv_quantity.setText(borrowed.getQuantity());
        holder.tv_transactionId.setText(borrowed.getTransactionId());

        holder.tv_titles.setOnClickListener(view -> {
            AppCompatActivity activity = (AppCompatActivity)view.getContext();
            activity.getSupportFragmentManager().beginTransaction().replace(R.id.drawer_layout, new ReturnFragment(borrowed.getBooktitle(), borrowed.getIsbn(), borrowed.getQuantity(), borrowed.getTransactionId(), borrowed.getBorrowdate(), borrowed.getReturndate(), borrowed.getBname(), borrowed.getIdnum())).addToBackStack(null).commit();
        });
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.container_history, parent, false);
        return new MyViewHolder(view);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tv_titles, tv_isbn, tv_quantity, tv_transactionId;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_titles = itemView.findViewById(R.id.tv_title);
            tv_isbn = itemView.findViewById(R.id.tv_isbn);
            tv_quantity = itemView.findViewById(R.id.tv_quantity);
            tv_transactionId = itemView.findViewById(R.id.tv_transactionId);
        }
    }
}