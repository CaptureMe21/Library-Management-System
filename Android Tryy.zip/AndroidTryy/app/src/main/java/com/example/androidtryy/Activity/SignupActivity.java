package com.example.androidtryy.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.androidtryy.Model.SignupHelper;
import com.example.androidtryy.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignupActivity extends AppCompatActivity {

    EditText signup_fname, signup_lname, signup_idnum, signup_email, signup_password;
    MaterialButton create_btn;
    TextView redirect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        signup_fname = findViewById(R.id.su_fname);
        signup_lname = findViewById(R.id.su_lname);
        signup_idnum = findViewById(R.id.su_idnum);
        signup_email = findViewById(R.id.su_email);
        signup_password = findViewById(R.id.su_password);
        create_btn = findViewById(R.id.ca_btn);
        redirect = findViewById(R.id.redirect_li);

        // Inside the create_btn onClickListener
        create_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String namef = signup_fname.getText().toString();
                String namel = signup_lname.getText().toString();
                String idnum = signup_idnum.getText().toString();
                String email = signup_email.getText().toString();
                String password = signup_password.getText().toString();
                int admin = 0;

                // Create user in Firebase Authentication
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(SignupActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Get the UID of the created user
                                    String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

                                    // Save additional user data in Realtime Database
                                    DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users");
                                    SignupHelper signupHelper = new SignupHelper(namef, namel, idnum, email, admin);
                                    usersRef.child(uid).setValue(signupHelper);

                                    // Display success message and navigate to TitleScreen
                                    Toast.makeText(SignupActivity.this, "User Account Created Successfully!", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(SignupActivity.this, TitleScreen.class);
                                    startActivity(intent);
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(SignupActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });

    }
}