package com.example.androidtryy.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.androidtryy.Model.BorrowHelper;
import com.example.androidtryy.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class BorrowActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference reference;
    TextView borrow_name, borrow_idnum, borrowbook_title, borrowbook_isbn, borrowbook_quantity, redirect;

    MaterialButton bb_btn, rb_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrow);

        // Initialize Firebase components
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Users");

        // Find views by their IDs
        borrow_name = findViewById(R.id.borrow_stname);
        borrow_idnum = findViewById(R.id.borrow_stidnum);
        borrowbook_isbn = findViewById(R.id.borrow_isbn);
        borrowbook_title = findViewById(R.id.borrowbook_btitle);
        borrowbook_quantity = findViewById(R.id.borrow_bquantity);
        redirect = findViewById(R.id.redirect_borrow);
        bb_btn = findViewById(R.id.bbbtn);

        redirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BorrowActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Get current user's UID
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Query the database to fetch user data
        reference.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Retrieve user data
                    String fname = dataSnapshot.child("namef").getValue(String.class);
                    String lname = dataSnapshot.child("namel").getValue(String.class);
                    String idNum = dataSnapshot.child("idnum").getValue(String.class);

                    // Populate borrow_name and borrow_idnum fields
                    borrow_name.setText(fname + " " + lname);
                    borrow_idnum.setText(idNum);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
            }
        });

        // Retrieve intent data for borrowing book
        Intent intent = getIntent();
        if (intent != null) {
            String booktitle = intent.getStringExtra("booktitle");
            String quantity = intent.getStringExtra("quantity");
            String isbn = intent.getStringExtra("isbn");

            borrowbook_title.setText(booktitle);
            borrowbook_isbn.setText(isbn);
            borrowbook_quantity.setText(quantity);
        }

        bb_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                DatabaseReference borrowedBooksRef = FirebaseDatabase.getInstance().getReference("BorrowedBooks");
                DatabaseReference transactionIdRef = FirebaseDatabase.getInstance().getReference("TransactionIDs");

                // Fetch the current transaction ID and increment it
                transactionIdRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            int currentTransactionId = dataSnapshot.getValue(Integer.class);
                            int nextTransactionId = currentTransactionId + 1;

                            // Update the transaction ID for the next transaction
                            transactionIdRef.setValue(nextTransactionId)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            // Create a new borrowing entry with the incremented transaction ID
                                            String transactionId = String.valueOf(nextTransactionId);

                                            // Retrieve other borrow details
                                            String bname = borrow_name.getText().toString();
                                            String idnum = borrow_idnum.getText().toString();
                                            String isbn = borrowbook_isbn.getText().toString();
                                            String booktitle = borrowbook_title.getText().toString();
                                            String quantity = borrowbook_quantity.getText().toString();

                                            // Get the current date
                                            String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

                                            // Calculate the expected return date (two days after the current date)
                                            Calendar calendar = Calendar.getInstance();
                                            calendar.add(Calendar.DAY_OF_YEAR, 2);
                                            String returndate = new SimpleDateFormat("yyyy-MM-dd").format(calendar.getTime());

                                            // Create a BorrowHelper object
                                            BorrowHelper borrowHelper = new BorrowHelper(bname, idnum, isbn, booktitle, quantity, uid, transactionId, currentDate, returndate);

                                            // Store borrowing details under the transaction ID node
                                            borrowedBooksRef.child(transactionId).setValue(borrowHelper)
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            // Book borrowing successful
                                                            DatabaseReference updateBooksRef = FirebaseDatabase.getInstance().getReference("Books");
                                                            updateBooksRef.child(isbn).child("quantity").setValue("0")
                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                        @Override
                                                                        public void onSuccess(Void aVoid) {
                                                                            // Book quantity updated successfully
                                                                            Toast.makeText(BorrowActivity.this, "Book Borrowed Successfully!", Toast.LENGTH_SHORT).show();
                                                                            Intent intent = new Intent(BorrowActivity.this, MainActivity.class);
                                                                            startActivity(intent);
                                                                        }
                                                                    })
                                                                    .addOnFailureListener(new OnFailureListener() {
                                                                        @Override
                                                                        public void onFailure(@NonNull Exception e) {
                                                                            // Failed to update book quantity
                                                                            Toast.makeText(BorrowActivity.this, "Failed to update book quantity: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                                        }
                                                                    });
                                                        }
                                                    })
                                                    .addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            // Failed to store borrowing details
                                                            Toast.makeText(BorrowActivity.this, "Failed to borrow book: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                        }
                                                    });
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            // Failed to update transaction ID
                                            Toast.makeText(BorrowActivity.this, "Failed to update transaction ID: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } else {
                            // Handle the case where the transaction ID node doesn't exist
                            // Initialize the transaction ID to a default value
                            int initialTransactionId = 1000000;
                            transactionIdRef.setValue(initialTransactionId);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Handle database error
                        Toast.makeText(BorrowActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}