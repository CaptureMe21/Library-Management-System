package com.example.androidtryy.Model;

public class SignupHelper {
    String namef;
    String namel;
    String idnum;
    String email;
    String password;
    int admin;

    public String getNamef() {
        return namef;
    }

    public void setNamef(String namef) {
        this.namef = namef;
    }

    public String getNamel() {
        return namel;
    }

    public void setNamel(String namel) {
        this.namel = namel;
    }

    public String getIdnum() {
        return idnum;
    }

    public void setIdnum(String idnum) {
        this.idnum = idnum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAdmin() {
        return admin;
    }

    public void setAdmin(int admin) {
        this.admin = admin;
    }

    public SignupHelper(String namef, String namel, String idnum, String email, int admin) {
        this.namef = namef;
        this.namel = namel;
        this.idnum = idnum;
        this.email = email;
        this.admin = admin;
    }
}

