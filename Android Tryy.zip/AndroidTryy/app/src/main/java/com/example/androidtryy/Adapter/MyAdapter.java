package com.example.androidtryy.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidtryy.Fragments.BookFragment;
import com.example.androidtryy.JavaClass.Booklist;
import com.example.androidtryy.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class MyAdapter extends FirebaseRecyclerAdapter<Booklist,MyAdapter.MyViewHolder> {

    public MyAdapter(@NonNull FirebaseRecyclerOptions<Booklist> options) {

        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull MyViewHolder holder, int position, @NonNull Booklist Booklist) {
        holder.tv_title.setText(Booklist.getBooktitle());
        holder.tv_author.setText(Booklist.getAuthor());
        holder.tv_pagenum.setText(Booklist.getPagenumber());
        holder.tv_quantity.setText(Booklist.getQuantity());
        holder.tv_category.setText(Booklist.getGenre());
        holder.tv_shelfnum.setText(Booklist.getShelfnumber());

        holder.tv_title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.drawer_layout, new BookFragment(Booklist.getBooktitle(), Booklist.getAuthor(), Booklist.getEdition(), Booklist.getVolume(), Booklist.getGenre(), Booklist.getQuantity(), Booklist.getShelfnumber(), Booklist.getPagenumber(), Booklist.getIsbn())).addToBackStack(null).commit();
            }
        });
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.container_booklist,parent,false);
        return new MyViewHolder(view);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tv_title, tv_pagenum, tv_author, tv_quantity, tv_category, tv_shelfnum;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_title = itemView.findViewById(R.id.tv_title);
            tv_pagenum = itemView.findViewById(R.id.tv_pagenum);
            tv_author = itemView.findViewById(R.id.tv_author);
            tv_quantity = itemView.findViewById(R.id.tv_quantity);
            tv_category = itemView.findViewById(R.id.tv_category);
            tv_shelfnum = itemView.findViewById(R.id.tv_shelfnum);
        }
    }
}