package com.example.androidtryy.JavaClass;

public class Booklist {

    String booktitle, pagenumber, author, edition, volume, quantity, genre, shelfnumber, isbn;

    public Booklist() {
    }

    public Booklist(String booktitle, String pagenumber, String author, String edition, String volume, String quantity, String genre, String shelfnumber, String isbn) {
        this.booktitle = booktitle;
        this.pagenumber = pagenumber;
        this.author = author;
        this.edition = edition;
        this.volume = volume;
        this.quantity = quantity;
        this.genre = genre;
        this.shelfnumber = shelfnumber;
        this.isbn = isbn;
    }

    public String getBooktitle() {
        return booktitle;
    }

    public void setBooktitle(String booktitle) {
        this.booktitle = booktitle;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getShelfnumber() {
        return shelfnumber;
    }

    public void setShelfnumber(String shelfnumber) {
        this.shelfnumber = shelfnumber;
    }

    public String getPagenumber() {
        return pagenumber;
    }

    public void setPagenumber(String pagenumber) {
        this.pagenumber = pagenumber;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}