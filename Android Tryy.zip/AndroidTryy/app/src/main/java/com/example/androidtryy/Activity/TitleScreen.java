package com.example.androidtryy.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.androidtryy.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TitleScreen extends AppCompatActivity {

    EditText usernamelogin, passwordlogin;
    MaterialButton login_btn;
    TextView redirect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_title_screen);

        usernamelogin = findViewById(R.id.li_username);
        passwordlogin = findViewById(R.id.li_password);
        login_btn = findViewById(R.id.li_btn);
        redirect = findViewById(R.id.redirect_create);

        redirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TitleScreen.this, SignupActivity.class);
                startActivity(intent);
            }
        });

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!validateUsername() | !validatePassword()) {
                    Toast.makeText(TitleScreen.this, "Username and password are required", Toast.LENGTH_SHORT).show();
                } else {
                    loginUser();
                }
            }
        });

        redirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TitleScreen.this, SignupActivity.class);
                startActivity(intent);
            }
        });
    }

    public Boolean validateUsername() {
        String val = usernamelogin.getText().toString();
        if (val.isEmpty()) {
            usernamelogin.setError("Username Cannot Be Empty");
            return false;
        } else {
            usernamelogin.setError(null);
            return true;
        }
    }

    public Boolean validatePassword() {
        String val = passwordlogin.getText().toString();
        if (val.isEmpty()) {
            passwordlogin.setError("Password Cannot Be Empty");
            return false;
        } else {
            passwordlogin.setError(null);
            return true;
        }
    }

    private void loginUser() {
        String userUsername = usernamelogin.getText().toString().trim();
        String userPassword = passwordlogin.getText().toString().trim();

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");

        mAuth.signInWithEmailAndPassword(userUsername, userPassword)
                .addOnCompleteListener(TitleScreen.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            String uid = mAuth.getCurrentUser().getUid();
                            reference.child(uid).child("last_login").setValue(getCurrentDate());
                            Intent intent = new Intent(TitleScreen.this, MainActivity.class);
                            startActivity(intent);

                        } else {

                            Toast.makeText(TitleScreen.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private String getCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }
}