package com.example.androidtryy.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.androidtryy.Fragments.BooklistFragment;
import com.example.androidtryy.Fragments.HistoryFragment;
import com.example.androidtryy.Fragments.HomeFragment;
import com.example.androidtryy.Fragments.MessageFragment;
import com.example.androidtryy.Fragments.ProfileFragment;
import com.example.androidtryy.R;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        replaceFragment(new HomeFragment(), R.id.nav_home);
        Toolbar toolbar = findViewById(R.id.toolbars);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationview = findViewById(R.id.navigationView);
        navigationview.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new HomeFragment()).commit();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.nav_home) {
            replaceFragment(new HomeFragment(), itemId);
        } else if (itemId == R.id.nav_booklist) {
            replaceFragment(new BooklistFragment(), itemId);
        } else if (itemId == R.id.nav_history) {
            replaceFragment(new HistoryFragment(), itemId);
        } else if (itemId == R.id.nav_profile) {
            replaceFragment(new ProfileFragment(), itemId);
        } else if (itemId == R.id.nav_message) {
            replaceFragment(new MessageFragment(), itemId);
        } else if (itemId == R.id.nav_logout) {
            startActivity(new Intent(MainActivity.this, TitleScreen.class));
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return false;
    }
    public void replaceFragment(Fragment fragment, int menuItemId) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();

        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setCheckedItem(menuItemId);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}