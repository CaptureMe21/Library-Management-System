package com.example.androidtryy.Model;

public class BorrowHelper {
    private String bname;
    private String idnum;
    private String isbn;
    private String booktitle;
    private String quantity;
    private String uid;
    private String transactionId;
    private String borrowdate;
    private String returndate;

    // Constructor with uid
    public BorrowHelper(String bname, String idnum, String isbn, String booktitle, String quantity, String uid, String transactionId, String borrowdate, String returndate) {
        this.bname = bname;
        this.idnum = idnum;
        this.isbn = isbn;
        this.booktitle = booktitle;
        this.quantity = quantity;
        this.uid = uid;
        this.transactionId = transactionId;
        this.borrowdate = borrowdate;
        this.returndate = returndate;

    }

    public String getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname = bname;
    }

    public String getIdnum() {
        return idnum;
    }

    public void setIdnum(String idnum) {
        this.idnum = idnum;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getBooktitle() {
        return booktitle;
    }

    public void setBooktitle(String booktitle) {
        this.booktitle = booktitle;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getBorrowdate() {
        return borrowdate;
    }

    public void setBorrowdate(String borrowdate) {
        this.borrowdate = borrowdate;
    }

    public String getReturndate() {
        return returndate;
    }

    public void setReturndate(String returndate) {
        this.returndate = returndate;
    }
}